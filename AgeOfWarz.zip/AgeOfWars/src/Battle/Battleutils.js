const { King } = require("../player/Player")



    const checkWinPossibilities = ( kingPlatoon ,OpponetPlatoon) => {
        for ( const [kingIdx , [kingPlatoonClass,kingSoldier]] of Object.entries(kingPlatoon) ){
            for ( const [oppIdx , [oppPlatoonClass,oppSoldier]] of Object.entries(OpponetPlatoon) ){
                if ( PlatoonAdvantages[kingPlatoonClass].includes(oppPlatoonClass)   ){
                    setWinPossibilites( kingSoldier * 2 ,  oppSoldier)
                }
                else  {
                    setWinPossibilites( kingSoldier  ,  oppSoldier)
                }
            }
        }
        }
        
        const setWinPossibilites = (kingSoldier,oppSoldier) => {
            if(kingSoldier > oppSoldier){
                King[kingPlatoonClass].canWinPlatoons = true 
                King[kingPlatoonClass].canWinPlatoonsList.push(oppIdx)
            }
            else if( kingSoldier == oppSoldier){
                King[kingPlatoonClass].drawPossiblePlatoonsList.push(oppIdx)
            }
        }


const sortConfirmProbabilties= () =>{

    for ( const [kingPlatoonClass,kingPlatoonObj] of Object.entries(King) ){
        if (kingPlatoonObj.noOfSoldiers >0 && kingPlatoonObj.canWinPlatoons ){
            if (kingPlatoonObj.canWinPlatoonsList.length == 1){
                King[kingPlatoonClass].newOrder = kingPlatoonObj.canWinPlatoonsList[0]
                removeAssignedOrder(kingPlatoonObj.canWinPlatoonsList[0])
            } 
        }   
    }

    if(isSingleWinFound()){
        sortConfirmProbabilties()
    }


}

const reOrderTroops = (KingPlatoonSoldierDtls ,OpponentPlatoonSoldierDtls) => {
    sortConfirmProbabilties()
    fixPositions()
    if (noOfWins == Object.keys(KingPlatoonSoldierDtls).length){
        setNewOrderAsGivenOrder()
        return
    }
    else{
        reOrderIterations()
    }
    // printTroops(OpponentPlatoonSoldierDtls)
}


const printTroops = (OpponentPlatoonSoldierDtls) => {

    let battleResult = "lose"
    console.log ( " own platoon    |   Opponent platoon   | outcome "  )
    for ( const [idx,[OpponentPlatoonClass,OpponentPlatoonObj]] of Object.entries( OpponentPlatoonSoldierDtls)  ){ //iterating through the keys 
            for ( const [idx,[kingPlatoonClass,kingPlatoonObj]] of Object.entries( King )  ){
            
                if ( King.newOrder ==  OpponentPlatoonObj.givenOrder ){

            if (OpponentPlatoonClass == kingPlatoonClass){
                if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers ){
                    battleResult == "win"
                } else if (kingPlatoonObj.noOfSoldiers == OpponentPlatoonObj.noOfSoldiers ){ {
                    battleResult = "draw"
                }
            }
            else {
                if (PlatoonAdvantages[OpponentPlatoonClass].includes(kingPlatoonClass)){
                    if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers *2  ){
                        battleResult == "win"
                    } else if (kingPlatoonObj.noOfSoldiers ==OpponentPlatoonObj.noOfSoldiers *2  ){
                        battleResult = "draw"
                    }
                   
                }
                else if (PlatoonAdvantages[kingPlatoonClass].includes(OpponentPlatoonClass) ){
                    if (kingPlatoonObj.noOfSoldiers*2  >OpponentPlatoonObj.noOfSoldiers ){
                        battleResult == "win"
                    } else if (kingPlatoonObj.noOfSoldiers*2  ==OpponentPlatoonObj.noOfSoldiers ){
                        battleResult = "draw"
                    }
                }
                else{
                    if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers ){
                        battleResult == "win"
                    } else if (kingPlatoonObj.noOfSoldiers == OpponentPlatoonObj.noOfSoldiers ) {
                        battleResult = "draw"
                    }
                }                 

            }
        }

        }

            console.log(kingPlatoonClass  + '|' + OpponentPlatoonClass + '|' +  battleResult)
        }

    
}
}

const setNewOrderAsGivenOrder =()=>{
    for ( const [kingIdx , [kingPlatoonClass,kingPlatoonObj]] of Object.entries(King) ){
        if (kingPlatoonObj.newOrder == -1){
            King[kingPlatoonClass].newOrder = King[kingPlatoonClass].givenOrder
        }
    }
}

const noOfWins = () => {
    let wins = 0
    for ( const [kingIdx , [kingPlatoonClass,kingPlatoonObj]] of Object.entries(King) ){
        let kingClassPosition = King[kingPlatoonClass].newOrder == -1 ? King[kingPlatoonClass].givenOrder : King[kingPlatoonClass].newOrd
        for ( const [OpponentIdx , [OpponentPlatoonClass,OpponentPlatoonObj]] of Object.entries(Opponent) ){
            if (Opponent[OpponentPlatoonClass].givenOrder ==kingClassPosition){
                if (OpponentPlatoonClass == kingPlatoonClass){
                if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers ){
                    wins++
                }
            }
            else {
                if (PlatoonAdvantages[OpponentPlatoonClass].includes(kingPlatoonClass)){
                    if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers *2  ){
                        wins++
                    }
                   
                }
                else if (PlatoonAdvantages[kingPlatoonClass].includes(OpponentPlatoonClass) ){
                    if (kingPlatoonObj.noOfSoldiers*2  >OpponentPlatoonObj.noOfSoldiers ){
                        wins++
                    }
                }
                else{
                    if (kingPlatoonObj.noOfSoldiers >OpponentPlatoonObj.noOfSoldiers ){
                        wins++
                    }
                }                 

            }
            }
        }

        }
        return wins
}

const fixPositions = () => {
    for ( const [kingPlatoonClass,kingPlatoonObj] of Object.entries(King) ){
        if ( kingPlatoonObj.newOrder ==-1 ){
            let isAnyWinFound  = false
            for ( const [kingIterationPlatoonClass,kingIterationPlatoonObj] of Object.entries(King) ){
                if( kingIterationPlatoonObj.canWinPlatoonsList.includes(kingPlatoonObj.givenOrder) ){
                   isAnyWinFound =true
                   break;
                }
            }
           if (!isAnyWinFound){
            King[kingPlatoonClass].newOrder = King[kingPlatoonClass].givenOrder
           }

        }
    }

}

const reOrderIterations = () => {

}


const isSingleWinFound = () => {
    let singleWin = false

    for ( const [kingPlatoonClass,kingPlatoonObj] of Object.entries(King) ){
        if (kingPlatoonObj.noOfSoldiers >0 && kingPlatoonObj.canWinPlatoonsList.length == 1 && kingPlatoonObj.newOrder == -1 ){
            singleWin =true
            break;
            } 
        }  

    return singleWin
}


const removeAssignedOrder =(order)=>{
    for ( const [kingIdx , [kingPlatoonClass,kingPlatoonObj]] of Object.entries(King) ){
            if(kingPlatoonObj.canWinPlatoonsList.includes(order)){
                let itemIndex = kingPlatoonObj.indexOf(order)
                King[kingPlatoonClass].canWinPlatoonsList.splice(itemIndex, 1)
            }
        }    
}




  module.exports = {checkWinPossibilities,reOrderTroops}