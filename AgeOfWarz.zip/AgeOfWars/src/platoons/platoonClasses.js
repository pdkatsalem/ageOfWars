const { MILITIA, SPEARMAN, LIGHTCAVALRY, HEAVYCAVALRY, CAVALRYARCHER,  FOOTARCHER} = require("./platoonConstants")

const PlatoonClasses = [
    MILITIA, 
    SPEARMAN, 
    LIGHTCAVALRY, 
    HEAVYCAVALRY, 
    CAVALRYARCHER, 
    FOOTARCHER
]


module.exports = { PlatoonClasses}