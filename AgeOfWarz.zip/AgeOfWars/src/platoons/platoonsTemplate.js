
const { PlatoonClasses } = require("./platoonClasses")

const platoonDetails ={}

const platoonObj = {
    noOfSoldiers : 0,
    givenOrder : -1,
    newOrder : -1,
    canWinPlatoons : false,
    canWinPlatoonsList :[],
    drawPossiblePlatoonsList :[]
}

PlatoonClasses.forEach( className  =>
    platoonDetails[className] = platoonObj
)

 module.exports = {platoonDetails}


 