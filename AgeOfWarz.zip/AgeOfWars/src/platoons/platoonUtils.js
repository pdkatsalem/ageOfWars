const { Opponent } = require("../player/Opponent")
const { King } = require("../player/Player")

const getPlatoonDetails = (inputPlatoon) => {
    const kingPlatoon = inputPlatoon.split(';')
    const platoonSoldierDtls = {}
    kingPlatoon.forEach(platoon => {
        const platoonSoldierList = platoon.split('#')
        platoonSoldierDtls[platoonSoldierList[0]] = parseInt(platoonSoldierList[1])
    }
    )
    return platoonSoldierDtls
}




module.exports ={getPlatoonDetails }
