const { reOrderTroops } = require('./Battle/Battleutils')
const { PlatoonAdvantages } = require('./platoons/platoonAdvantage')
const { getPlatoonDetails } = require('./platoons/platoonUtils')
const { default: Opponent, assignOpponentTroops } = require('./player/Opponent')
const { default: King, assignKingTroops } = require('./player/Player')

let KingPlatoonSoldierDtls = {}

let OpponentPlatoonSoldierDtls = {}



const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
});

readline.question('Input King platoons', platoonList => {

    KingPlatoonSoldierDtls = getPlatoonDetails(platoonList)

    readline.close();
});


readline.question('Input King platoons', platoonList => {

    OpponentPlatoonSoldierDtls = getPlatoonDetails(platoonList)

    readline.close();
});

//king platoon

assignKingTroops(KingPlatoonSoldierDtls)

//Opponent platoon

assignOpponentTroops(OpponentPlatoonSoldierDtls)

reOrderTroops(KingPlatoonSoldierDtls,OpponentPlatoonSoldierDtls)

