const platoonDetails = require( "../platoons/platoonsTemplate")

const Opponent = platoonDetails

const assignOpponentTroops = (OpponentPlatoonSoldierDtls) => {

    for ( const [idx , [platoon,soldiers]] of Object.entries( OpponentPlatoonSoldierDtls)  ){  //iterating through the keys 
        Opponent[platoon].noOfSoldiers = soldiers  
        Opponent[platoon].givenOrder = idx
        Opponent[platoon].newOrder = idx
        }
        
}

module.exports={ Opponent,assignOpponentTroops}