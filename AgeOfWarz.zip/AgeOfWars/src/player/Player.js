const { platoonDetails } = require("../platoons/platoonsTemplate")
let King = platoonDetails

const assignKingTroops = (KingPlatoonSoldierDtls) => {
    for ( const [idx,[platoon,soldiers]] of Object.entries( KingPlatoonSoldierDtls)  ){ //iterating through the keys 
        King[platoon].noOfSoldiers = soldiers  
        King[platoon].givenOrder = idx
        }
}


module.exports = { King,assignKingTroops }
