-get/scan the list of platoon class along soldiers count for both king and opponent
-have the platoonclass list with noofsoldier ,givenorder ,neworder ==>

const platoonObj = {
    noOfSoldiers : 0,
    givenOrder : -1,
    newOrder : -1,
    canWinPlatoons : false,
    canWinPlatoonsList :[],
    drawPossiblePlatoonsList :[]
}

-iterate the king platoon list to check whether the king platoon class could win over any of the opponent class
- if any single win found then 
    `canWinPlatoons` is set to true 
    list of win order is pushed into the array `canWinPlatoonsList`


-set the new order for the king platoon class list through the following order 
    - set the new order if only one win case is found and remove the order possibilities in the other classes so we will reduce the iterations 
    - iterate the next set of winpossiblities one by one and check the no of wins and exit loop

- make the function to get the no of wins for the current order to fetch the data for the iteration results with new set of orders